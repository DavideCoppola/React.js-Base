import React from "react";

import CourseGoalItem from "../CourseGoalItem/CourseGoalItem";
import "./CourseGoalList.css";

type CourseGoalListProps = {
  items: {id: string, text: string}[];
  onDeleteItem: Function;
}

const CourseGoalList = (props: CourseGoalListProps) => {
  return (
    <ul className="goal-list">
      {props.items.map((goal: { id: string; text: string }) => (
        <CourseGoalItem
          key={goal.id}
          id={goal.id}
          onDelete={props.onDeleteItem}
        >
          {goal.text}
        </CourseGoalItem>
      ))}
    </ul>
  );
};

export default CourseGoalList;
