import React, { MouseEventHandler } from "react";

import styles from "./Button.module.css";

type ButtonProps = {
  type: any;
  /* onClick: MouseEventHandler<HTMLButtonElement>; */
  children: any;
};

const Button = (props: ButtonProps) => {
  return (
    <button type={props.type} className={styles.button} /* onClick={props.onClick} */>
      {props.children}
    </button>
  );
};

export default Button;
